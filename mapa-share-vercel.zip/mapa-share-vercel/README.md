# Mapa de Share KA Ceará

Painel estático (um único `index.html`) que salva os dados no Supabase.

## Publicar na Vercel
1. Suba `index.html` e este `README.md` num repositório do GitHub.
2. Na Vercel: **Add New → Project → Import** o repositório. Framework: **Other**. Sem build. Deploy.

## Configurar o login no Supabase (uma vez)
Supabase → **Authentication → URL Configuration**
- **Site URL**: o endereço da Vercel (ex.: `https://mapa-share-ce.vercel.app`)
- **Redirect URLs**: adicione o mesmo endereço

Login com Google (opcional, recomendado): **Authentication → Sign In / Providers → Google**, cole o Client ID e o Client Secret criados no Google Cloud Console
(OAuth client "Web application", redirect URI: `https://cpyxwzsrvhzljjpgbfmv.supabase.co/auth/v1/callback`).

Só e-mails `@praso.com.br` conseguem ler e gravar (regras de acesso no banco).
